<?php
// 파일 인코딩을 반드시 UTF-8 (BOM 없음)로 저장하세요.
header('Content-Type: text/html; charset=utf-8');

$host = '192.168.20.50';
$db   = '은행';                 // ← 한글 DB명
$user = 'bankapp';
$pass = '1234';

$dsn  = "mysql:host=$host;dbname=$db;charset=utf8mb4";

$options = [
  PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
  $pdo = new PDO($dsn, $user, $pass, $options);
  // (선택) 콜레이션도 맞추고 싶다면 한 번 실행
  // $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_general_ci");

  // 001 → 002로 5,000원 이체 (모두 한글 식별자이므로 백틱(`)으로 감싸기)
  $pdo->beginTransaction();

  $stmt1 = $pdo->prepare("UPDATE `계좌` SET `잔액` = `잔액` - :amt WHERE `계좌번호` = :no");
  $stmt1->execute([':amt' => 5000, ':no' => '001']);

  $stmt2 = $pdo->prepare("UPDATE `계좌` SET `잔액` = `잔액` + :amt WHERE `계좌번호` = :no");
  $stmt2->execute([':amt' => 5000, ':no' => '002']);

  $pdo->commit();
  echo "<p>이체 성공 (계좌번호 001 →  계좌번호 002 : 5,000원)</p>";

  /* ① 001, 002 잔액 조회 */
  $sql = "SELECT `계좌번호`, `이름`, `잔액`
          FROM `계좌`
          WHERE `계좌번호` IN ('001','002')
          ORDER BY `계좌번호`";

  $stmt = $pdo->query($sql);
  $rows = $stmt->fetchAll();

  /* ② 간단한 HTML 표로 출력 */
  echo "<h3>계좌 잔액</h3>";
  echo "<table border='1' cellpadding='6' cellspacing='0'>
          <tr>
            <th>계좌번호</th><th>이름</th><th>잔액</th>
          </tr>";
  foreach ($rows as $r) {
      // 안전한 출력
      $no   = htmlspecialchars($r['계좌번호'], ENT_QUOTES, 'UTF-8');
      $name = htmlspecialchars($r['이름'],     ENT_QUOTES, 'UTF-8');
      $bal  = number_format((int)$r['잔액']);
      echo "<tr><td>{$no}</td><td>{$name}</td><td style='text-align:right'>{$bal}</td></tr>";
  }
  echo "</table>";

} catch (Throwable $e) {
  if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
  http_response_code(500);
  echo "오류: " . htmlspecialchars($e->getMessage(), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
?>
